// wacky.js
// Formula to convert unicorns to fairies.
// Formula is: weight of unicorn * 3.14 / megillagrams of magic inside of the unicorns horn + number of hairs inside unicorn's left nostril.


var uniWeight = 100;

console.log("If your unicorn weighs " + uniWeight + " pounds,");

var megMil = "2300";

console.log("And if the unicorn's horn contains " + megMil + " megillagrams of magic, ");

var uniHair = 17000;
var pi = 3.14;

console.log("And your unicorn's left nostril contains " + uniHair + " hairs.. ");

var fairyConv;
fairyConv = uniWeight * pi / megMil + uniHair;

var myRound = parseInt(fairyConv);

console.log("With the amount of unicorn you have, you can convert that to " + myRound + " fairies.");

